from app.models import db, AuditLog
from flask_login import current_user
from datetime import datetime

def log_action(action_text):
    if current_user.is_authenticated:
        log = AuditLog(user_id=current_user.id, action=action_text)
        db.session.add(log)
        db.session.commit()
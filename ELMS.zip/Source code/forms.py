from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, SubmitField, DateField, TextAreaField, SelectField
from wtforms.validators import DataRequired, Email, Length



class LoginForm(FlaskForm):
    username = StringField('Username', validators=[DataRequired()])
    password = PasswordField('Password', validators=[DataRequired()])
    submit = SubmitField('Login')

class LeaveForm(FlaskForm):
    start_date = DateField('Start Date', validators=[DataRequired()])
    end_date = DateField('End Date', validators=[DataRequired()])
    leave_type = SelectField(
        'Leave Type',
        choices=[
            ('annual', 'Annual Leave'),
            ('sick', 'Sick Leave'),
            ('personal', 'Personal Leave'),
            ('emergency', 'Emergency Leave')
        ],
        validators=[DataRequired()]
    )
    reason = TextAreaField('Reason', validators=[DataRequired(), Length(max=500)])
    submit = SubmitField('Submit Request')
class AddUserForm(FlaskForm):
    username = StringField('Username', validators=[DataRequired()])
    role = SelectField('Role', choices=[('employee', 'employee'), ('manager', 'manager'), ('admin', 'admin')], validators=[DataRequired()])
    password = PasswordField('Password', validators=[DataRequired()])
    submit = SubmitField('Create User')
from flask import Blueprint, render_template, redirect, url_for, flash, request
from flask_login import login_required, current_user
from app import db
from app.models import LeaveRequest
from forms import LeaveForm
from datetime import datetime
from app.models import Leave

# ✅ Import log_action helper
from utils import log_action

employee_bp = Blueprint('employee', __name__, url_prefix='/employee')

@employee_bp.route('/dashboard')
@login_required
def dashboard():
    if current_user.role != 'employee':
        return redirect(url_for('auth.login'))

    leaves = Leave.query.filter_by(user_id=current_user.id).all()
    return render_template('employee/dashboard.html', leaves=leaves)

@employee_bp.route('/apply', methods=['GET', 'POST'])
@login_required
def apply_leave():
    if current_user.role != 'employee':
        return redirect(url_for('auth.login'))

    form = LeaveForm()
    if form.validate_on_submit():
        new_leave = Leave(
            user_id=current_user.id,
            leave_type=form.leave_type.data,
            start_date=form.start_date.data,
            end_date=form.end_date.data,
            reason=form.reason.data,
            status='Pending',
            applied_date=datetime.utcnow()  # ✅ Set applied_date here
        )
        db.session.add(new_leave)
        db.session.commit()

        log_action(f"Applied for leave: {form.start_date.data} to {form.end_date.data}")

        flash('Leave request submitted!', 'success')
        return redirect(url_for('employee.dashboard'))

    return render_template('employee/apply_leave.html', form=form)


@employee_bp.route('/cancel/<int:leave_id>')
@login_required
def cancel_leave(leave_id):
    leave = LeaveRequest.query.get_or_404(leave_id)
    if leave.user_id != current_user.id or leave.status != "Pending":
        flash("You can't cancel this leave.", "danger")
        return redirect(url_for('employee.dashboard'))

    leave.status = "Cancelled"
    db.session.commit()

    # ✅ Log cancel leave action
    log_action(f"Cancelled leave ID: {leave_id}")

    flash('Leave request cancelled.', 'info')
    return redirect(url_for('employee.dashboard'))
@employee_bp.route('/leave/<int:leave_id>')
@login_required
def view_leave(leave_id):
    leave = Leave.query.get_or_404(leave_id)
    return render_template('employee/view_leave.html', leave=leave)
@employee_bp.route('/edit/<int:leave_id>', methods=['GET', 'POST'])
@login_required
def edit_leave(leave_id):
    if current_user.role != 'employee':
        return redirect(url_for('auth.login'))

    

    leave = Leave.query.get_or_404(leave_id)

    if leave.user_id != current_user.id:
        flash("Unauthorized access to this leave request.", "danger")
        return redirect(url_for('employee.dashboard'))

    if leave.status != 'Pending':
        flash("You can only edit leave requests that are still pending.", "warning")
        return redirect(url_for('employee.dashboard'))

    form = LeaveForm(obj=leave)

    if form.validate_on_submit():
        leave.leave_type = form.leave_type.data
        leave.start_date = form.start_date.data
        leave.end_date = form.end_date.data
        leave.reason = form.reason.data
        db.session.commit()

        log_action(f"Edited leave ID: {leave.id}")
        flash("Leave request updated successfully.", "success")
        return redirect(url_for('employee.dashboard'))

    return render_template('employee/edit_leave.html', form=form, leave=leave)
@employee_bp.route('/cancel_request/<int:leave_id>')
@login_required
def cancel_leave_request(leave_id):
    if current_user.role != 'employee':
        return redirect(url_for('auth.login'))



    leave = LeaveRequest.query.get_or_404(leave_id)

    if leave.user_id != current_user.id:
        flash("Unauthorized action.", "danger")
        return redirect(url_for('employee.dashboard'))

    if leave.status != "Pending":
        flash("Only pending leave requests can be cancelled.", "warning")
        return redirect(url_for('employee.dashboard'))

    leave.status = "Cancelled"
    db.session.commit()

    log_action(f"Cancelled leave request ID: {leave_id}")
    flash("Leave request has been cancelled.", "info")
    return redirect(url_for('employee.dashboard'))

from flask import Blueprint, render_template, redirect, url_for, send_file, flash, make_response, flash, request
from flask_login import login_required, current_user
from app import db
from app.models import User, LeaveRequest, AuditLog, Leave
from utils import log_action
from forms import AddUserForm
from werkzeug.security import generate_password_hash
from weasyprint import HTML
from sqlalchemy import extract




import io
import pandas as pd
from reportlab.lib.pagesizes import letter
from reportlab.pdfgen import canvas

# Define Blueprint
admin_bp = Blueprint('admin', __name__, url_prefix='/admin')

# ------------------------------
# Admin Dashboard
# ------------------------------
@admin_bp.route('/dashboard')
@login_required
def dashboard():
    if current_user.role != 'admin':
        return redirect(url_for('auth.login'))

    users = User.query.all()
    leaves = Leave.query.all()
    logs = AuditLog.query.order_by(AuditLog.timestamp.desc()).all()  # 🔥 Get recent logs

    stats = {
        "total_users": len(users),
        "total_leaves": len(leaves),
        "approved": len([l for l in leaves if l.status == "Approved"]),
        "rejected": len([l for l in leaves if l.status == "Rejected"]),
        "pending": len([l for l in leaves if l.status == "Pending"]),
    }

    return render_template('admin/dashboard.html', stats=stats, users=users, leaves=leaves, logs=logs)


# ------------------------------
# View Audit Logs
# ------------------------------
@admin_bp.route('/audit')
@login_required
def view_audit_logs():
    if current_user.role != 'admin':
        return redirect(url_for('auth.login'))

    try:
        with open('audit.log', 'r') as f:
            logs = f.readlines()
    except FileNotFoundError:
        logs = ["No logs found."]

    return render_template('admin/audit_logs.html', logs=logs)

# ------------------------------
# Add User
# ------------------------------

@admin_bp.route('/add_user', methods=['GET', 'POST'])
@login_required
def add_user():
    if current_user.role != 'admin':
        return redirect(url_for('auth.login'))

    form = AddUserForm()
    if form.validate_on_submit():
        existing_user = User.query.filter_by(username=form.username.data).first()
        if existing_user:
            flash('Username already exists. Please choose another one.', 'danger')
            return redirect(url_for('admin.add_user'))  # Stay on the same page

        # Create new user instance
        new_user = User(
            username=form.username.data,
            password=generate_password_hash(form.password.data),  # Secure the password
            role=form.role.data
        )

        # Save to database
        db.session.add(new_user)
        db.session.commit()
        log_action(f"Admin added user: {form.username.data}")

        flash('New user added successfully!', 'success')
        return redirect(url_for('admin.dashboard'))  # Redirect to dashboard to reflect changes

    return render_template('admin/add_user.html', form=form)
# ------------------------------
# Delete User
# ------------------------------
@admin_bp.route('/delete_user/<int:user_id>')
@login_required
def delete_user(user_id):
    if current_user.role != 'admin':
        return redirect(url_for('auth.login'))

    user = User.query.get_or_404(user_id)
    deleted_username=user.username
    db.session.delete(user)
    db.session.commit()

    log_action(f"Admin deleted user: {deleted_username}")  # ✅ Log action here
    flash('User deleted successfully!', 'success')
    return redirect(url_for('admin.dashboard'))

#-------------------------------
#exporting reports
#-------------------------------------
@admin_bp.route('/export_leaves_pdf')
@login_required
def export_leaves_pdf():
    if current_user.role != 'admin':
        return redirect(url_for('auth.login'))

    month = request.args.get('month')  # Format: YYYY-MM
    if not month:
        flash("Please select a month.", "danger")
        return redirect(url_for('admin.dashboard'))

    year, month_num = map(int, month.split('-'))

    # Get all leaves (approved or rejected) for that month
    leaves = (Leave.query
              .join(User)
              .filter(extract('year', Leave.start_date) == year)
              .filter(extract('month', Leave.start_date) == month_num)
              .order_by(Leave.start_date.desc())
              .all())

    rendered = render_template('admin/leaves_pdf.html', leaves=leaves, month=month)
    pdf = HTML(string=rendered).write_pdf()

    response = make_response(pdf)
    response.headers['Content-Type'] = 'application/pdf'
    response.headers['Content-Disposition'] = f'inline; filename=leave_requests_{month}.pdf'
    return response
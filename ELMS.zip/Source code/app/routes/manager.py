from flask import Blueprint, render_template, redirect, url_for, request, flash
from flask_login import login_required, current_user
from app import db
from app.models import Leave,LeaveRequest,User
from utils import log_action  # ✅ Added for audit logging
from datetime import datetime


manager_bp = Blueprint('manager', __name__, url_prefix='/manager')


@manager_bp.route('/dashboard')
@login_required
def dashboard():
    if current_user.role != 'manager':
        return redirect(url_for('auth.login'))
    
    status_filter = request.args.get('status')
    
    if status_filter:
        leaves = Leave.query.filter_by(status=status_filter).all()
    else:
        leaves = Leave.query.all()

    total_requests = len(leaves)
    pending_requests = Leave.query.filter_by(status='Pending').count()

    return render_template(
        'manager/dashboard.html',
        leaves=leaves,
        total_requests=total_requests,
        pending_requests=pending_requests
    )

    # Get query parameters from filter form
    status_filter = request.args.get('status')
    employee_filter = request.args.get('employee')
    from_date = request.args.get('from_date')
    to_date = request.args.get('to_date')

    # Start base query
    query = Leave.query.join(User)

    # Apply filters
    if status_filter:
        query = query.filter(Leave.status == status_filter)

    if employee_filter:
        query = query.filter(User.username.ilike(f"%{employee_filter}%"))

    if from_date:
        query = query.filter(Leave.start_date >= from_date)

    if to_date:
        query = query.filter(Leave.end_date <= to_date)

    # Final result
    leaves = query.order_by(Leave.applied_date.desc()).all()

    return render_template('manager/dashboard.html', leaves=leaves)


@manager_bp.route('/approve/<int:leave_id>')
@login_required
def approve_leave(leave_id):
    if current_user.role != 'manager':
        return redirect(url_for('auth.login'))

    leave = Leave.query.get_or_404(leave_id)
    

    leave.status = "Approved"
    leave.reviewed_date = datetime.utcnow()
    db.session.commit()

    leave_log = LeaveRequest(
        employee_id=leave.user_id,
        start_date=leave.start_date,
        end_date=leave.end_date,
        reason=leave.reason,
        status="Approved"
    )
    db.session.add(leave_log)

    log_action(f"Manager approved leave ID: {leave.id}")  # ✅ Log the action

    flash('Leave approved.', 'success')
    return redirect(url_for('manager.dashboard'))

@manager_bp.route('/reject/<int:leave_id>')
@login_required
def reject_leave(leave_id):
    leave = Leave.query.get_or_404(leave_id)
    if current_user.role != 'manager':
        return redirect(url_for('auth.login'))

    leave.status = "Rejected"
    leave.reviewed_date = datetime.utcnow()
    db.session.commit()

    log_action(f"manager rejected leave ID: {leave.id}")  # ✅ Log the action

    flash('Leave rejected.', 'danger')
    return redirect(url_for('manager.dashboard'))
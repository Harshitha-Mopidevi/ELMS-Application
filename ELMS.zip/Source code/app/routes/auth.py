from flask import Blueprint, render_template, redirect, url_for, flash, request, current_app
from flask_login import login_user, logout_user, current_user
from app import db, login_manager
from app.models import User
from forms import LoginForm
from werkzeug.security import check_password_hash

# ✅ Import log_action from utils.py
from utils import log_action

auth_bp = Blueprint('auth', __name__)

# ✅ Route only for login page
@auth_bp.route('/login', methods=['GET', 'POST'])
def login():
    # Debug log
    current_app.logger.info(f"[Login Page] Authenticated: {current_user.is_authenticated}")

    if current_user.is_authenticated:
        # Only redirect if role's dashboard route exists
        role = current_user.role
        dashboard_endpoint = f"{role}.dashboard"

        try:
            # This will raise BuildError if the endpoint doesn't exist
            return redirect(url_for(dashboard_endpoint))
        except Exception as e:
            current_app.logger.warning(f"Redirect failed: {e}")
            flash("Dashboard not found for your role.", "danger")
            logout_user()
            return redirect(url_for('auth.login'))

    form = LoginForm()
    if form.validate_on_submit():
        user = User.query.filter_by(username=form.username.data).first()
        if user and check_password_hash(user.password, form.password.data):
            login_user(user)
            log_action("Logged in")
            current_app.logger.info(f"[Login Success] Role: {user.role}")

            role = user.role
            dashboard_endpoint = f"{role}.dashboard"

            try:
                return redirect(url_for(dashboard_endpoint))
            except Exception as e:
                current_app.logger.warning(f"Redirect failed: {e}")
                flash("Dashboard not found for your role.", "danger")
                return redirect(url_for('auth.login'))

        flash('Invalid credentials', 'danger')

    return render_template('auth/login.html', form=form)


@auth_bp.route('/logout')
def logout():
    if current_user.is_authenticated:
        log_action("Logged out")
    logout_user()
    return redirect(url_for('auth.login'))


# ✅ Optional: Redirect `/` to login or dashboard if needed
@auth_bp.route('/')
def index():
    if current_user.is_authenticated:
        role = current_user.role
        dashboard_endpoint = f"{role}.dashboard"
        try:
            return redirect(url_for(dashboard_endpoint))
        except Exception:
            return redirect(url_for('auth.login'))
    return redirect(url_for('auth.login'))